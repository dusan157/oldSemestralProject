#pragma once
#include "Filter_1.h"
#include "Oblast.h"
class FilterNazov : public Filter_fi<std::string, Oblast> {};