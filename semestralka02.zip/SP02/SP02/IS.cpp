#include "IS.h"

IS::IS()
{
	kraje = new structures::SortedSequenceTable<int, Kraj*>;
	okresy = new structures::SortedSequenceTable<int, Okres*>;
	obce = new structures::SortedSequenceTable<int, Obec*>;
	neutriedObce = new structures::UnsortedSequenceTable<int, Obec*>;
}

IS::~IS()
{
	for (auto item : *obce) {
		delete item->accessData();
	}
	delete obce;
	for (auto item : *okresy) {
		delete item->accessData();
	}
	delete okresy;
	for (auto item : *kraje) {
		delete item->accessData();
	}
	delete kraje;
	delete neutriedObce;
}

void IS::nacitanie()
{
	std::ifstream citac;
	std::string riadok;
	Okres* okres;
	Obec *obec;
	Kraj *kraj;
	int i = 0;
	int kod;
	citac.open("kraje.csv");
	while (getline(citac, riadok, ',')) {
		kraj = new Kraj();
		kod = stoi(riadok); // kod obce
		i = 0;
		for (i = 0; i < 11; i++) {
			getline(citac, riadok, ','); //obec +data
			kraj->setData(i, riadok);
		}
		kraje->insert(kod, kraj);
	}
	citac.close();

	citac.open("okresy.csv");

	while (getline(citac, riadok, ',')) {
		kod = stoi(riadok); // kod kraju
		if (!kraje->tryFind(kod, kraj)) {
			kraj = new Kraj();
			getline(citac, riadok, ',');
			kraj->setData(0, riadok);
			kraje->insert(kod, kraj);
		}
		else {
			getline(citac, riadok, ',');
		}

		getline(citac, riadok, ',');
		kod = stoi(riadok); // kod okresu
		okres = new Okres();
		i = 0;
		for (i = 0; i < 11; i++) {
			getline(citac, riadok, ','); //obec +data
			okres->setData(i, riadok);
		}
		okresy->insert(kod, okres);
		kraj->insert(kod, okres);
		
	}
	citac.close();



	citac.open("obce.csv");
	while (getline(citac, riadok, ',')) {
		kod = stoi(riadok); // kod kraju
		if (!kraje->tryFind(kod, kraj)) {
			kraj = new Kraj();
			getline(citac, riadok, ',');
			kraj->setData(0, riadok);
			kraje->insert(kod, kraj);
		}
		else {
			getline(citac, riadok, ',');
		}
		getline(citac, riadok, ',');
		kod = stoi(riadok); // kod okresu

		if (!kraj->tryFind(kod, okres)) {
			okres = new Okres();
			getline(citac, riadok, ',');
			okres->setData(0, riadok);
			kraj->insert(kod, okres);
			okresy->insert(kod, okres);
		}
		else {
			getline(citac, riadok, ',');
		}

		obec = new Obec();
		getline(citac, riadok, ',');
		kod = stoi(riadok); // kod obce
		i = 0;
		for (i = 0; i < 11; i++) {
			getline(citac, riadok, ','); //obec +data
			obec->setData(i, riadok);
		}
		okres->insert(kod, obec);
		obce->insert(kod, obec);
		neutriedObce->insert(kod, obec);
	}
	for (auto kraj : *kraje) {
		kraj->accessData()->setOkresy();
		for (auto okres : *kraj->accessData()) {
			okres->accessData()->setObce();
		}
	}
	citac.close();

	citac.open("hlasyKraje1.csv");
	while (getline(citac, riadok, ',')) {
		int cKraj = stoi(riadok);
		kraje->tryFind(cKraj, kraj);
		getline(citac, riadok, ',');
		getline(citac, riadok, ',');
		string meno = riadok;
		//meno+=" "+riadok;
		getline(citac, riadok);
		kraj->setDataKandidati(meno, 0, stoi(riadok));
	}
	citac.close();

	citac.open("hlasyKraje2.csv");
	while (getline(citac, riadok, ',')) {
		int cKraj = stoi(riadok);
		kraje->tryFind(cKraj, kraj);
		getline(citac, riadok, ',');
		getline(citac, riadok, ',');
		string meno = riadok;
		//meno += " " + riadok;
		getline(citac, riadok);
		kraj->setDataKandidati(meno, 1, stoi(riadok));
	}
	citac.close();

	citac.open("hlasyOkresy1.csv");
	while (getline(citac, riadok, ',')) {
		int cOkres = stoi(riadok);
		okresy->tryFind(cOkres, okres);
		getline(citac, riadok, ',');
		getline(citac, riadok, ',');
		string meno = riadok;
		getline(citac, riadok);
		okres->setDataKandidati(meno, 0, stoi(riadok));
	}
	citac.close();

	citac.open("hlasyOkresy2.csv");
	while (getline(citac, riadok, ',')) {
		int cOkres = stoi(riadok);
		okresy->tryFind(cOkres, okres);
		getline(citac, riadok, ',');
		getline(citac, riadok, ',');
		string meno = riadok;
		getline(citac, riadok,',');
		okres->setDataKandidati(meno, 1, stoi(riadok));
		getline(citac, riadok); //dalo to tam ciarky
	}
	citac.close();

	citac.open("hlasyObce1.csv");
	while (getline(citac, riadok, ',')) {
		int cObec = stoi(riadok);
		obce->tryFind(cObec, obec);
		getline(citac, riadok, ',');
		getline(citac, riadok, ',');
		string meno = riadok;
		getline(citac, riadok);
		obec->setDataKandidati(meno, 0, stoi(riadok));
	}
	citac.close();

	citac.open("hlasyObce2.csv");
	while (getline(citac, riadok, ',')) {
		int cObec = stoi(riadok);
		obce->tryFind(cObec, obec);
		getline(citac, riadok, ',');
		getline(citac, riadok, ',');
		string meno = riadok;
		getline(citac, riadok, ',');
		obec->setDataKandidati(meno, 1, stoi(riadok));
		getline(citac, riadok); //dalo to tam ciarky
	}
	citac.close();


	riadok = "";
	obec = nullptr;
	delete obec;
	okres = nullptr;
	delete okres;
	kraj = nullptr;
	delete kraj;
}

void IS::vypisInfoNazov(int index,string vyraz)
{
	filt_Nazov.setAlpha(vyraz);
	switch (index) {
	case 1: {
		for (auto obec : *obce) {
			if (filt_Nazov.evaluate(*obec->accessData(), krit_Nazov)) {
				cout <<"Nazov kraja: " <<krit_Nazov.evaluate(*obec->accessData()->getKraj()) <<endl;
				cout << "Nazov okresu: " << krit_Nazov.evaluate(*obec->accessData()->getOkres()) << endl;
				cout << "Nazov obce:" << krit_Nazov.evaluate(*obec->accessData()) << endl;
				vypisData(obec->accessData());
			}
		}
	}
			break;
	case 2: {
		for (auto okres : *okresy) {	
			if (filt_Nazov.evaluate(*okres->accessData(), krit_Nazov)) {
				cout << "Nazov kraja: " << krit_Nazov.evaluate(*okres->accessData()->getKraj()) << endl;
				cout << "Nazov okresu: " << krit_Nazov.evaluate(*okres->accessData()) << endl;
				vypisData(okres->accessData());
			}
		}
	}
			break;
	case 3: {
		for (auto kraj : *kraje) {
			if (filt_Nazov.evaluate(*kraj->accessData(), krit_Nazov)) {
				cout << "Nazov kraj: " << krit_Nazov.evaluate(*kraj->accessData()) << endl;
				vypisData(kraj->accessData());
			}
		}
	}
			break;

	}
}

void IS::vypisInfoVolici(int index,int kolo, int alfa,int beta)
{
	filt_Volici.setAlpha(alfa);
	filt_Volici.setBeta(beta);
	krit_Volici.setKolo(kolo - 1);


	switch (index) {
	case 1: {
		for (auto obec : *obce) {
			if (filt_Volici.evaluate(*obec->accessData(), krit_Volici)) {
				cout << "Nazov kraja: " << krit_Nazov.evaluate(*obec->accessData()->getKraj()) << endl;
				cout << "Nazov okres: " << krit_Nazov.evaluate(*obec->accessData()->getOkres()) << endl;
				cout << "Nazov obce:" << krit_Nazov.evaluate(*obec->accessData()) << endl;
				vypisData(obec->accessData());
			}
		}
	}
			break;
	case 2: {
		for (auto okres : *okresy) {
			if (filt_Volici.evaluate(*okres->accessData(), krit_Volici)) {
				cout << "Nazov kraja: " << krit_Nazov.evaluate(*okres->accessData()->getKraj()) << endl;
				cout << "Nazov okres: " << krit_Nazov.evaluate(*okres->accessData()) << endl;
				vypisData(okres->accessData());
			}
		}
	}
			break;
	case 3: {
		for (auto kraj : *kraje) {
			if (filt_Volici.evaluate(*kraj->accessData(), krit_Volici)) {
				cout << "Nazov kraj: " << krit_Nazov.evaluate(*kraj->accessData()) << endl;
				vypisData(kraj->accessData());
			}
		}
	}
			break;

	}
}

void IS::vypisInfoUcast(int index, int kolo, float alfa, float beta)
{
	filt_Ucast.setAlpha(alfa);
	filt_Ucast.setBeta(beta);
	krit_Ucast.setKolo(kolo - 1);


	switch (index) {
	case 1: {
		for (auto obec : *obce) {
			if (filt_Ucast.evaluate(*obec->accessData(), krit_Ucast)) {
				cout << "Nazov kraja: " << krit_Nazov.evaluate(*obec->accessData()->getKraj()) << endl;
				cout << "Nazov okres: " << krit_Nazov.evaluate(*obec->accessData()->getOkres()) << endl;
				cout << "Nazov obce:" << krit_Nazov.evaluate(*obec->accessData()) << endl;
				vypisData(obec->accessData());
			}
		}
	}
			break;
	case 2: {
		for (auto okres : *okresy) {
			if (filt_Ucast.evaluate(*okres->accessData(), krit_Ucast)) {
				cout << "Nazov kraja: " << krit_Nazov.evaluate(*okres->accessData()->getKraj()) << endl;
				cout << "Nazov okres: " << krit_Nazov.evaluate(*okres->accessData()) << endl;
				vypisData(okres->accessData());
			}
		}
	}
			break;
	case 3: {
		for (auto kraj : *kraje) {
			if (filt_Ucast.evaluate(*kraj->accessData(), krit_Ucast)) {
				cout << "Nazov kraj: " << krit_Nazov.evaluate(*kraj->accessData()) << endl;
				vypisData(kraj->accessData());
			}
		}
	}
			break;

	}
}

void IS::vypisUtriedeneNazov(int utriedenie)
{
	structures::HeapSort<int, Obec*> triedenie;
	KomparatorNazov komparator;
	komparator.setUsporiadanie(utriedenie);
	triedenie.sort(*neutriedObce, komparator);
	for (auto item : *neutriedObce) {
		cout << krit_Nazov.evaluate(*item->accessData()) << endl;
	}
}

void IS::vypisUtriedeneVolici(int kolo, int utriedenie)
{
	structures::HeapSort<int, Obec*> triedenie;
	KomparatorVolici komparator;
	komparator.setKolo(kolo-1);
	komparator.setUsporiadanie(utriedenie);
	krit_Volici.setKolo(kolo-1);
	triedenie.sort(*neutriedObce, komparator);
	for (auto item : *neutriedObce) {
		cout << krit_Nazov.evaluate(*item->accessData()) <<" "<< krit_Volici.evaluate(*item->accessData()) <<endl;
	}
}

void IS::vypisUtriedeneUcast(int kolo, int utriedenie)
{
	structures::HeapSort<int, Obec*> triedenie;
	KomparatorUcast komparator;
	komparator.setKolo(kolo - 1);
	komparator.setUsporiadanie(utriedenie);
	krit_Ucast.setKolo(kolo - 1);
	triedenie.sort(*neutriedObce, komparator);
	for (auto item : *neutriedObce) {
		cout << krit_Nazov.evaluate(*item->accessData()) << " " << krit_Ucast.evaluate(*item->accessData()) << endl;
	}
}

void IS::vypisUtriedeneFiltrovaneNazov(int utriedenie, string nazov,int kolo, int alfa, int beta)
{
	krit_Prislusnost.setOblast(nazov);
	krit_Ucast.setKolo(kolo-1);
	filt_Ucast.setAlpha(alfa);
	filt_Ucast.setBeta(beta);
	structures::HeapSort<int, Obec*> triedenie;
	KomparatorNazov komparator;
	komparator.setUsporiadanie(utriedenie);
	triedenie.sort(*neutriedObce, komparator);
	for (auto item : *neutriedObce) {
		if (krit_Prislusnost.evaluate(*item->accessData()) && filt_Ucast.evaluate(*item->accessData(), krit_Ucast)) {
			cout << krit_Nazov.evaluate(*item->accessData()) << endl;
		}
	}
}

void IS::vypisUtriedeneFiltrovaneVolici(int utriedenie, string nazov,int kolo, int alfa, int beta)
{
	krit_Prislusnost.setOblast(nazov);
	krit_Ucast.setKolo(kolo - 1);
	filt_Ucast.setAlpha(alfa);
	filt_Ucast.setBeta(beta);
	krit_Volici.setKolo(kolo - 1);
	structures::HeapSort<int, Obec*> triedenie;
	KomparatorVolici komparator;
	komparator.setKolo(kolo - 1);
	komparator.setUsporiadanie(utriedenie);
	triedenie.sort(*neutriedObce, komparator);
	for (auto item : *neutriedObce) {
		if (krit_Prislusnost.evaluate(*item->accessData()) && filt_Ucast.evaluate(*item->accessData(), krit_Ucast)) {
			cout << krit_Nazov.evaluate(*item->accessData()) << " " << krit_Volici.evaluate(*item->accessData()) << endl;
		}
	}
}

void IS::vypisUtriedeneFiltrovaneUcast(int utriedenie, string nazov, int kolo, int alfa, int beta)
{
	krit_Prislusnost.setOblast(nazov);
	krit_Ucast.setKolo(kolo - 1);
	filt_Ucast.setAlpha(alfa);
	filt_Ucast.setBeta(beta);
	krit_Ucast.setKolo(kolo - 1);
	structures::HeapSort<int, Obec*> triedenie;
	KomparatorUcast komparator;
	komparator.setKolo(kolo - 1);
	komparator.setUsporiadanie(utriedenie);
	triedenie.sort(*neutriedObce, komparator);
	for (auto item : *neutriedObce) {
		if (krit_Prislusnost.evaluate(*item->accessData()) && filt_Ucast.evaluate(*item->accessData(), krit_Ucast)) {
			cout << krit_Nazov.evaluate(*item->accessData()) << " " << krit_Ucast.evaluate(*item->accessData()) << endl;
		}
	}
}

void IS::nastavKombinaciuFiltrov(int i)
{
	cout << "Zadajte volbu pomocou volby:" << endl;
	cout << " 1 - Filter nazov \t 2 - Filter volici \t 3 -Filter ucast" << endl;
	cout << " 4 - Filter nazov a volici \t 5 - Filter nazov a ucast \t 6 - Filter volici ucast" << endl;
	cout << " 7 - Filter nazov, volici a ucast" << endl;
	cin >> i;
	switch (i) {
	case 1: {
		cout << "Zadajte nazov/vyraz pre filtrovanie obce" << endl;
		string pom;
		cin >> pom;
		filt_Nazov.setAlpha(pom);
	}
			break;
	case 2: {
		cout << "Zadajte spodnu hranicu intervalu volicov " << endl;
		int pom;
		cin >> pom;
		filt_Volici.setAlpha(pom);
		cout << "Zadajte hornu hranicu intervalu volicov " << endl;
		cin >> pom;
		filt_Volici.setBeta(pom);

	}
			break;
	case 3: {
		cout << "Zadajte spodnu hranicu intervalu ucasti " << endl;
		int pom;
		cin >> pom;
		filt_Ucast.setAlpha(pom);
		cout << "Zadajte hornu hranicu intervalu ucasti " << endl;
		cin >> pom;
		filt_Ucast.setBeta(pom);
	}
			break;
	case 4: {
		cout << "Zadajte nazov/vyraz pre filtrovanie obce" << endl;
		string pom;
		cin >> pom;
		filt_Nazov.setAlpha(pom);
		cout << "Zadajte spodnu hranicu intervalu volicov " << endl;
		int pom1;
		cin >> pom1;
		filt_Volici.setAlpha(pom1);
		cout << "Zadajte hornu hranicu intervalu volicov " << endl;
		cin >> pom1;
		filt_Volici.setBeta(pom1);
	}
			break;
	case 5: {
		cout << "Zadajte nazov/vyraz pre filtrovanie obce" << endl;
		string pom;
		cin >> pom;
		filt_Nazov.setAlpha(pom);
		cout << "Zadajte spodnu hranicu intervalu ucasti " << endl;
		int pom1;
		cin >> pom1;
		filt_Ucast.setAlpha(pom1);
		cout << "Zadajte hornu hranicu intervalu ucasti " << endl;
		cin >> pom1;
		filt_Ucast.setBeta(pom1);
	}
			break;
	case 6: {
		cout << "Zadajte spodnu hranicu intervalu volicov " << endl;
		int pom;
		cin >> pom;
		filt_Volici.setAlpha(pom);
		cout << "Zadajte hornu hranicu intervalu volicov " << endl;
		cin >> pom;
		filt_Volici.setBeta(pom);

		cout << "Zadajte spodnu hranicu intervalu ucasti " << endl;
		cin >> pom;
		filt_Ucast.setAlpha(pom);
		cout << "Zadajte hornu hranicu intervalu ucasti " << endl;
		cin >> pom;
		filt_Ucast.setBeta(pom);
	}
			break;
	case 7: {
		cout << "Zadajte nazov/vyraz pre filtrovanie obce" << endl;
		string pom;
		cin >> pom;
		filt_Nazov.setAlpha(pom);
		cout << "Zadajte spodnu hranicu intervalu volicov " << endl;
		int pom1;
		cin >> pom1;
		filt_Volici.setAlpha(pom1);
		cout << "Zadajte hornu hranicu intervalu volicov " << endl;
		cin >> pom1;
		filt_Volici.setBeta(pom1);

		cout << "Zadajte spodnu hranicu intervalu ucasti " << endl;
		cin >> pom1;
		filt_Ucast.setAlpha(pom1);
		cout << "Zadajte hornu hranicu intervalu ucasti " << endl;
		cin >> pom1;
		filt_Ucast.setBeta(pom1);
	}
			break;
	}
}

void IS::vypisData(Oblast * kraj)
{
	
	krit_Volici.setKolo(0);
	cout << "Volici: 1.Kolo :" << to_string(krit_Volici.evaluate(*kraj));
	krit_Volici.setKolo(1);
	cout << " 2. Kolo :" << to_string(krit_Volici.evaluate(*kraj)) << endl;

	krit_VydaneObalky.setKolo(0);
	cout << "Vydane obalky: 1.Kolo :" << to_string(krit_VydaneObalky.evaluate(*kraj));
	krit_VydaneObalky.setKolo(1);
	cout << " 2. Kolo :" << to_string(krit_VydaneObalky.evaluate(*kraj)) << endl;

	krit_Ucast.setKolo(0);
	cout << "Ucast: 1.Kolo :" << to_string(krit_Ucast.evaluate(*kraj));
	krit_Ucast.setKolo(1);
	cout << " 2. Kolo :" << to_string(krit_Ucast.evaluate(*kraj)) << endl;

	krit_OdovzdaneObalky.setKolo(0);
	cout << "Odovzdane obalky: 1.Kolo :" << to_string(krit_OdovzdaneObalky.evaluate(*kraj));
	krit_OdovzdaneObalky.setKolo(1);
	cout << " 2. Kolo :" << to_string(krit_OdovzdaneObalky.evaluate(*kraj)) << endl;

	krit_OdovzdaneHlasy.setKolo(0);
	cout << "Odovzdane hlasy: 1.Kolo :" << to_string(krit_OdovzdaneHlasy.evaluate(*kraj));
	krit_OdovzdaneHlasy.setKolo(1);
	cout << " 2. Kolo :" << to_string(krit_OdovzdaneHlasy.evaluate(*kraj)) << endl;
	cout << endl;
}
