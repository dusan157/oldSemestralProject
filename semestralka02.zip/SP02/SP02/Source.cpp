﻿#include "IS.h"
int main()
{
	initHeapMonitor();
	IS *is = new IS();
	//is->nacitanie();
	/*char volba;
	cin >> volba;
	while (volba!='x') {
		switch (volba) {
		case 'a': {
			cout << "vyberte mnozinu 1 = obce; 2 = okresy; 3 = kraje" << endl;
			int usporiadanie;
			cin >> usporiadanie;
			cout << "Zadajte nazov/cast nazvu pre filtrovanie mnoziny" << endl;
			string vyraz;
			cin >> vyraz;
			is->vypisInfoNazov(usporiadanie,vyraz);
		}
		case 'b': {

		}
		}
		cin >> volba;
	}*/
	//is->vypisUtriedeneFiltrovaneUcast(0, "Nitra",2, 10.0, 100.0);
	is->testik();
		delete is;

	}