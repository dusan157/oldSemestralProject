#pragma once
#include "Filter_2.h"
#include "Oblast.h"
class FilterUcast : public Filter_FI<float, Oblast> {};