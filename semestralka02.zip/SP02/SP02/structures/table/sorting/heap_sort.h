#pragma once
#include "sort.h"
#include "../unsorted_sequence_table.h"

namespace structures
{

	/// <summary> Triedenie Heap sort. </summary>
	/// <typeparam name = "K"> Kluc prvkov v tabulke. </typepram>
	/// <typeparam name = "T"> Typ dat ukladanych v tabulke. </typepram>
	template <typename K, typename T>
	class HeapSort : public Sort<K, T>
	{
	public:
		/// <summary> Utriedi tabulku triedenim Heap sort. </summary>
		/// <param name = "table"> NonortedSequenceTable, ktoru ma utriedit. </param>
		void sort(UnsortedSequenceTable<K, T>& table,Komparator<K,T>& komparator) override;
	};

	template<typename K, typename T>
	inline void HeapSort<K, T>::sort(UnsortedSequenceTable<K, T>& table,Komparator<K,T>& komparator)
	{
		bool vymena;
		for (int i = 1; i < table.size() - 1; i++) {
			int aktualny = i;
			do {
				vymena = false;
				int otec = (aktualny - 1) / 2;
				if (aktualny > 0 && komparator.porovnaj(table.getItemAtIndex(aktualny), table.getItemAtIndex(otec))) {
					std::swap(table.getItemAtIndex(aktualny), table.getItemAtIndex(otec));
					aktualny = otec;
					vymena = true;
				}

			} while (vymena);
			notify();
		}

		for (int i = table.size() - 1; i > 1; i--) {
			std::swap(table.getItemAtIndex(0), table.getItemAtIndex(i));
			int aktualny = 0;
			do {
				int max;
				vymena = false;
				int lavy = aktualny * 2 + 1;
				int pravy = aktualny * 2 + 2;
				if (lavy < i && pravy < i) {
					max = komparator.porovnaj(table.getItemAtIndex(lavy), table.getItemAtIndex(pravy)) ? lavy : pravy;
				}
				else {
					max = lavy < i ? lavy : pravy;
				}
				if (max < i && komparator.porovnaj(table.getItemAtIndex(max), table.getItemAtIndex(aktualny))) {
					std::swap(table.getItemAtIndex(max), table.getItemAtIndex(aktualny));
					aktualny = max;
					vymena = true;
				}


			} while (vymena);
			//notify();
		}
	}

}