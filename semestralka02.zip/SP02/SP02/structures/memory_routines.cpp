#include "memory_routines.h"

namespace structures {
	byte & MemoryRoutines::byteSet(byte & B)
	{
		//TODO 01: MemoryRoutines
		return B;
	}
	byte & MemoryRoutines::byteReset(byte & B)
	{
		//TODO 01: MemoryRoutines
		return B;
	}
	byte & MemoryRoutines::byteXOR(byte & B)
	{
		//TODO 01: MemoryRoutines
		return B;
	}
	byte & MemoryRoutines::byteSHL(byte & B)
	{
		//TODO 01: MemoryRoutines
		return B;
	}
	byte & MemoryRoutines::byteSHR(byte & B)
	{
		//TODO 01: MemoryRoutines
		return B;
	}
	bool MemoryRoutines::byteNthBitGet(byte & B, int n)
	{
		//TODO 01: MemoryRoutines
		return false;
	}

	byte & MemoryRoutines::byteNthBitTo0(byte & B, int n)
	{
		//TODO 01: MemoryRoutines
		return B;
	}

	byte & MemoryRoutines::byteNthBitTo1(byte & B, int n)
	{
		//TODO 01: MemoryRoutines
		return B;
	}

	byte & MemoryRoutines::byteNthBitToggle(byte & B, int n)
	{
		//TODO 01: MemoryRoutines
		return B;
	}

	MemoryRoutines::MemoryRoutines()
	{
	}

}
