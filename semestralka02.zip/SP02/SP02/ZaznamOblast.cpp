#include "ZaznamOblast.h"



ZaznamOblast::ZaznamOblast(int pVolici,int pVydaneObalky,int pOdovzdaneObalky,int pHlasy,double pUcast)
{
	volici = pVolici;
	vydaneObalky= pVydaneObalky;
	odovzdaneObalky= pOdovzdaneObalky;
	odovzdaneHlasy = pHlasy;
	ucast= pUcast;
}


ZaznamOblast::~ZaznamOblast()
{
}
