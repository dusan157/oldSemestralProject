#pragma once
#include "Oblast.h"
#include "Kriterium.h"
class KriteriumVydaneObalky : public Kriterium<int, Oblast> {
public:
	int evaluate(Oblast& oblast) override
	{
		return oblast.getVydaneObalky(kolo);
	}
	inline void setKolo(int pKolo) {
		kolo = pKolo;
	}
private:
	int kolo;
};