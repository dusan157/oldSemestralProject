#pragma once
#include "Filter_1.h"
#include "Kandidat.h"
class FilterMeno : public Filter_fi<std::string, Kandidat&> {};