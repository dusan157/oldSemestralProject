#pragma once
#include "Filter_2.h"
#include "Oblast.h"
class FilterVolici : public Filter_FI<int, Oblast> {};